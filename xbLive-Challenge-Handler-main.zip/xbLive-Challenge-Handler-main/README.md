# xbLive Challenge Handler
 Dynamically handle Xbox 360 code challenges.
